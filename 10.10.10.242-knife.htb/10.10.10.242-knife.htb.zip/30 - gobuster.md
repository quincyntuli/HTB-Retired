# gobuster
command : gobuster dir -w /opt/SecLists/Discovery/Web-Content/raft-large-directories.txt -u http://knife.htb -x htm,html,asp,aspx,php,php3,php7

![[Pasted image 20210601001352.png]]

- no hits on neither raft* nor directory-list-medium
- FuFF did not find anything either

