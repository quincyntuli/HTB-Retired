# Burpsuite
On bursuite, there is a reference in the hearders to 
````bash
X-Powered-By: PHP/8.1.0-dev
````
![[12-secs.webm]]