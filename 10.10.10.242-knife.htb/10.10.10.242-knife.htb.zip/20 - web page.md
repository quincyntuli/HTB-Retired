# Web Page

![[Pasted image 20210531235755.png]]

- no clickable links
- no robots.txt


